function home() { 
    window.location.href = "../index.html";
};