<?php
 session_start();
if(isset($_SESSION['login'])){
?>
<html>

<head>
<title>User Control Pannel - URLATLAS</title>
</head>
<body>
<h1>This is your control pannel to create new lists.</h1>
<div>

<a href='logout.php'>log out</a><br><br><br><br>

<form>

<label>Your List:</label><br> <br>
<textarea name="Text1" cols="40" rows="5"></textarea>
<br><br><br><br><br>
<label>Name you would like to be displayed:</label><br><br>
<input type="text"><br><br><br> <br><br> <br>
<input type="submit">

</form>


</div>
</body>
</html>


<?php
}
else {
    echo "access not granted. Try registering or logging in first.";
}

?>