<?php

session_start();
 $_SESSION['login'] = 'login';



 
 
$con = mysqli_connect('localhost','xxxxx','xxxxx');
mysqli_select_db($con, 'webswptt_register');
$name = $_POST['user'];
$pass = $_POST['password'];
$query = "select * from registertable where name = '$name' ";
$query2 = "select * from registertable where name = '$pass' ";
$result = mysqli_query($con,$query);
$result2 = mysqli_query($con,$query2);
$num = mysqli_num_rows($result);
$num2 = mysqli_num_rows($result2);

if($num==1&&$num2==1){
    echo "you are logged in...please wait...";
        header("refresh:2;url=landing.php");

}

else{
   echo "Sorry, the username or password doesn't seem to be correct.";
    
}
?>